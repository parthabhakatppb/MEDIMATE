import os
from flask import Flask, request, session, jsonify
from langchain_huggingface import HuggingFaceEmbeddings  # Updated import
from langchain.chains import RetrievalQA
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import PromptTemplate
from langchain_community.llms import HuggingFaceHub
import json

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Required for session management

# Configuration
HUGGINGFACE_REPO_ID = "mistralai/Mistral-7B-Instruct-v0.3"
DB_FAISS_PATH = "vectorstore/db_faiss"

# Initialize components once
def get_vectorstore():
    embedding_model = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
    return FAISS.load_local(DB_FAISS_PATH, embedding_model, allow_dangerous_deserialization=True)

def set_custom_prompt():
    return PromptTemplate(
        template="""Using only the provided context, answer the question below with a detailed and clear solution.
        Do not include any additional information such as the context, prompt instructions, or source details.
        
        Question: {question}
        Context: {context}
        
        Answer:""",
        input_variables=["context", "question"]
    )

def load_llm(hf_token):
    return HuggingFaceHub(
        repo_id=HUGGINGFACE_REPO_ID,
        huggingfacehub_api_token=hf_token,
        model_kwargs={"temperature": 0.5, "max_length": 512}
    )

# Initialize components at app start
vectorstore = get_vectorstore()
HF_TOKEN = os.getenv("HUGGINGFACE_API_TOKEN") or "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"
qa_chain = RetrievalQA.from_chain_type(
    llm=load_llm(HF_TOKEN),
    chain_type="stuff",
    retriever=vectorstore.as_retriever(search_kwargs={'k': 3}),
    return_source_documents=False,
    chain_type_kwargs={'prompt': set_custom_prompt()}
)

# Only POST route is available
@app.route('/', methods=['POST'])
def chat():
    # Ensure the session has a messages list
    if 'messages' not in session:
        session['messages'] = []

    # Expecting JSON payload with a "message" key
    data = request.get_json()
    if not data or 'message' not in data:
        return jsonify({"error": "Please provide a JSON payload with a 'message' key."}), 400

    user_input = data['message']
    session['messages'].append({'role': 'user', 'content': user_input})

    try:
        response = qa_chain.invoke({'query': user_input})
        raw_response = response["result"].strip()

        # Clean response by removing template fragments
        cleaned_response = raw_response.split("Answer:")[-1].strip()
        cleaned_response = cleaned_response.split("Context:")[0].strip()
        cleaned_response = cleaned_response.replace("GALE ENCYCLOPEDIA OF MEDICINE 2", "")

        # Remove any remaining question/context references
        forbidden_phrases = [
            "Using only the provided context", 
            "Do not include any additional information",
            "Question:", 
            "Context:"
        ]
        for phrase in forbidden_phrases:
            cleaned_response = cleaned_response.replace(phrase, "")

        session['messages'].append({'role': 'assistant', 'content': cleaned_response})
        session.modified = True

    except Exception as e:
        session['messages'].append({'role': 'assistant', 'content': f"Error: {str(e)}"})
        session.modified = True
        
    return jsonify(session['messages'])

if __name__ == '__main__':
    app.run(debug=True, port=5000)


# import os
# from flask import Flask, render_template, request, session
# from langchain_huggingface import HuggingFaceEmbeddings  # Updated import
# from langchain.chains import RetrievalQA
# from langchain_community.vectorstores import FAISS
# from langchain_core.prompts import PromptTemplate
# from langchain_community.llms import HuggingFaceHub

# app = Flask(__name__)
# app.secret_key = os.urandom(24)  # Required for session management

# # Configuration
# HUGGINGFACE_REPO_ID = "mistralai/Mistral-7B-Instruct-v0.3"
# DB_FAISS_PATH = "vectorstore/db_faiss"

# # Initialize components once
# def get_vectorstore():
#     embedding_model = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
#     return FAISS.load_local(DB_FAISS_PATH, embedding_model, allow_dangerous_deserialization=True)

# def set_custom_prompt():
#     return PromptTemplate(
#         template="""Using only the provided context, answer the question below with a detailed and clear solution.
#         Do not include any additional information such as the context, prompt instructions, or source details.
        
#         Question: {question}
#         Context: {context}
        
#         Answer:""",
#         input_variables=["context", "question"]
#     )

# def load_llm(hf_token):
#     return HuggingFaceHub(
#         repo_id=HUGGINGFACE_REPO_ID,
#         huggingfacehub_api_token=hf_token,
#         model_kwargs={"temperature": 0.5, "max_length": 512}
#     )

# # Initialize components at app start
# vectorstore = get_vectorstore()
# HF_TOKEN = os.getenv("HUGGINGFACE_API_TOKEN") or "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"
# qa_chain = RetrievalQA.from_chain_type(
#     llm=load_llm(HF_TOKEN),
#     chain_type="stuff",
#     retriever=vectorstore.as_retriever(search_kwargs={'k': 3}),
#     return_source_documents=False,
#     chain_type_kwargs={'prompt': set_custom_prompt()}
# )

# # Updated chat route with response cleaning
# @app.route('/', methods=['GET', 'POST'])
# def chat():
#     if 'messages' not in session:
#         session['messages'] = []

#     if request.method == 'POST':
#         user_input = request.form['message']
#         session['messages'].append({'role': 'user', 'content': user_input})

#         try:
#             response = qa_chain.invoke({'query': user_input})
#             raw_response = response["result"].strip()
            
#             # Clean response by removing template fragments
#             cleaned_response = raw_response.split("Answer:")[-1].strip()
#             cleaned_response = cleaned_response.split("Context:")[0].strip()
#             cleaned_response = cleaned_response.replace("GALE ENCYCLOPEDIA OF MEDICINE 2", "")
            
#             # Remove any remaining question/context references
#             forbidden_phrases = ["Using only the provided context", 
#                                "Do not include any additional information",
#                                "Question:", 
#                                "Context:"]
#             for phrase in forbidden_phrases:
#                 cleaned_response = cleaned_response.replace(phrase, "")

#             session['messages'].append({'role': 'assistant', 'content': cleaned_response})
#             session.modified = True

#         except Exception as e:
#             session['messages'].append({'role': 'assistant', 'content': f"Error: {str(e)}"})
#             session.modified = True

#     return render_template('chat.html', messages=session['messages'])

# if __name__ == '__main__':
#     app.run(debug=True, port=5000)


# import os
# from flask import Flask, render_template, request, session
# from langchain_huggingface import HuggingFaceEmbeddings  # Updated import
# from langchain.chains import RetrievalQA
# from langchain_community.vectorstores import FAISS
# from langchain_core.prompts import PromptTemplate
# from langchain_community.llms import HuggingFaceHub

# app = Flask(__name__)
# app.secret_key = os.urandom(24)  # Required for session management

# # Configuration
# HUGGINGFACE_REPO_ID = "mistralai/Mistral-7B-Instruct-v0.3"
# DB_FAISS_PATH = "vectorstore/db_faiss"

# # Initialize components once
# def get_vectorstore():
#     embedding_model = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
#     return FAISS.load_local(DB_FAISS_PATH, embedding_model, allow_dangerous_deserialization=True)

# def set_custom_prompt():
#     return PromptTemplate(
#         template="""Using only the provided context, answer the question below with a detailed and clear solution.
#         Do not include any additional information such as the context, prompt instructions, or source details.
        
#         Question: {question}
#         Context: {context}
        
#         Answer:""",
#         input_variables=["context", "question"]
#     )

# def load_llm(hf_token):
#     return HuggingFaceHub(
#         repo_id=HUGGINGFACE_REPO_ID,
#         huggingfacehub_api_token=hf_token,
#         model_kwargs={"temperature": 0.5, "max_length": 512}
#     )

# # Initialize components at app start
# vectorstore = get_vectorstore()
# HF_TOKEN = os.getenv("HUGGINGFACE_API_TOKEN") or "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"
# qa_chain = RetrievalQA.from_chain_type(
#     llm=load_llm(HF_TOKEN),
#     chain_type="stuff",
#     retriever=vectorstore.as_retriever(search_kwargs={'k': 3}),
#     return_source_documents=False,
#     chain_type_kwargs={'prompt': set_custom_prompt()}
# )

# # Updated chat route with response cleaning
# @app.route('/', methods=['GET', 'POST'])
# def chat():
#     if 'messages' not in session:
#         session['messages'] = []

#     if request.method == 'POST':
#         user_input = request.form['message']
#         session['messages'].append({'role': 'user', 'content': user_input})

#         try:
#             response = qa_chain.invoke({'query': user_input})
#             raw_response = response["result"].strip()
            
#             # Clean response by removing template fragments
#             cleaned_response = raw_response.split("Answer:")[-1].strip()
#             cleaned_response = cleaned_response.split("Context:")[0].strip()
#             cleaned_response = cleaned_response.replace("GALE ENCYCLOPEDIA OF MEDICINE 2", "")
            
#             # Remove any remaining question/context references
#             forbidden_phrases = ["Using only the provided context", 
#                                "Do not include any additional information",
#                                "Question:", 
#                                "Context:"]
#             for phrase in forbidden_phrases:
#                 cleaned_response = cleaned_response.replace(phrase, "")

#             session['messages'].append({'role': 'assistant', 'content': cleaned_response})
#             session.modified = True

#         except Exception as e:
#             session['messages'].append({'role': 'assistant', 'content': f"Error: {str(e)}"})
#             session.modified = True

#     return render_template('chat.html', messages=session['messages'])
# if __name__ == '__main__':
#     app.run(debug=True,PORT = 5000)