const express = require("express");
const router = express.Router();
const passport = require("passport");
const User = require("../models/user.js");

router.route("/signup")
    .get((req, res) => {
        return res.render("signup.ejs");
    })
    .post(async (req, res) => {
        try {
            let { firstName, lastName, username, email, password, age, gender, phoneNo } = req.body;
            const newUser = new User({ firstName, lastName, username, email, password, age, gender, phoneNo });
            const registeredUser = await User.register(newUser, password);
            
            req.login(registeredUser, (err) => {
                if (err) {
                    return next(err);
                }
                return res.redirect("/chat");
            });

        } catch (err) {
            if (err.name == "UserExistsError") {
                // req.flash("error", "User names already exists!");
                return res.redirect("/authentication/signup");
            }
            if(err.errors.gender){
                // req.flash("error", "Please select the gender");
                return res.redirect("/authentication/signup")
            }
            return res.redirect("/authentication/signup");
        }
    })


router.route("/login")
    .get((req, res) => {
        return res.render("login.ejs");
    })
    .post(
        passport.authenticate("local", {
            failureRedirect: '/authentication/login',
            failureFlash: true
        }),
        (req, res) => {
            return res.redirect("/chat");
        }
    )


module.exports = router;