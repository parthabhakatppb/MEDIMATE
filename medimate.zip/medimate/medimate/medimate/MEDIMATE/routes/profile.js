const express = require("express");
const { isLoggedIn } = require("../middleware");
const User = require("../models/user.js");
const Chat = require("../models/chat.js");
const router = express.Router();

router.route("/")
    .get(isLoggedIn, async (req, res)=>{
        const user = await User.findById(req.user._id).populate("appointments");
        const chats = await Chat.find({owner: user._id}).populate('owner');
        return res.render("profile.ejs", {user, chats});
    })

module.exports = router;

// form validation 
// schema validation
// validation error handling