const express = require("express");
const Appointment = require("../models/appointment.js");
const { isLoggedIn } = require("../middleware");
const User = require("../models/user.js");
const router = express.Router();

router.route("/")
    .get(isLoggedIn, (req, res)=>{
        return res.render("appointmentForm.ejs");
    })
    .post(async (req, res)=>{
        let {atHospital, date, time} = req.body;
        const newAppointment = new Appointment({atHospital, date, time});
        const currUser = await User.findById(req.user._id);
        if(!req.user){
            return res.redirect("/authentication/login");
        }
        newAppointment.patient = req.user._id;
        currUser.appointments.push(newAppointment);

        await newAppointment.save();
        await currUser.save();
        return res.redirect("/profile");
    })

module.exports = router;