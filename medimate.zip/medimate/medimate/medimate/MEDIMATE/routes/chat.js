const express = require("express");
const router = express.Router({ mergeParams: true });
const { isLoggedIn } = require("../middleware.js");
const axios = require("axios");
const Chat = require("../models/chat.js");
const User = require("../models/user.js");

router.route("/")
    .get(isLoggedIn, (req, res) => {
        return res.render("chat.ejs", {chatId:"", document: ""});
    })
    .post(async (req, res)=>{
        const userMessage = req.body.msg;
        console.log("User chat message at express: "+userMessage);
        if (!userMessage) {
            return res.status(400).json({ error: "Message is required" });
        }

        const response = await axios.post('http://localhost:5000/', {
            message: userMessage
        });
        res.json(response.data[1].content);
    })

router.route("/:id/save")
    .post(async (req, res)=>{
        const {chatId} = req.params;
        const newDoc = req.body.chatContent;
        await Chat.findByIdAndUpdate(chatId, { $set: { doc: newDoc }});
        res.send("chat Updated!");
    })

router.route("/open/:id")
    .get(async (req, res) => {
        let { id } = req.params;  // Extracting 'id' instead of 'chatId'
        let chat = await Chat.findById(id);  // Using the correct variable
        res.render("chat.ejs", { chatId: id, document: chat.doc });  // Rendering with the correct variable
    });


router.route("/open/:id")
    .get(async (req, res)=>{
        let {chatId} = req.params;
        let chat = await Chat.findById(chatId);
        res.render("chat.ejs", {chatId, document : chat.doc});
    })
// router.route("/c/:id")
//     .get((req, res) => {
//         // fetch listing with id in req.params
//         console.log("get req on chat/c/:id received");
//         const { id } = req.params;
//         res.render("chat.ejs", { id });  // passing the id so in script of this ejs file we can store the id and send a post request to the same route for communicating with the model
//     })
//     .post((req, res) => {
//         // communicate with the model
//         res.send("post req on chat/c/:id received");
//         // MLmodelSocket.emit("chatMessage", req.body.msg);
//         // MLmodelSocket.once("chatMessageResponse", (response)=>{
//         //     res.send(response);
//         // });
//     })
//     .put((req, res) => {
//         res.send("put req on chat/c/:id received");
//         // store the the chat-div.innerHTML in     
//     })

// router.route("/c") // redirect to here when user clicks on <input>
//     .post(async (req, res) => {
//         console.log("post req on chat/c received");
//         let newChat = new Chat({ doc: "", owner: req.user });
//         const id = newChat._id;
//         await newChat.save();
//         // create an object (newChat) of model class 'chat' then .save() it // then fetch the Id of that object (document) [newChat._id would return the ObjectId for this chat]
//         res.redirect(`/chat/c/${id}`);  // redirect to the page
//     })


module.exports = router;



// script of chat.ejs: jaise hee message send ka button click hoga .addEventListener('click', (e)=>{ function(){send post request to model with userMessage, receive model's response, show it in the html}.then((response)=>{}) function(){send put request to /c/id with the id of chat and with the chat-div innerHTML stored in a string variable and sent as a string variable  }
// specific chat waale div ko chat layout mei daldena

// how to trigger an event only the first time the element was clicked. if i click the second time the event should not be triggered

// make sure to make a different div inside chat.ejs which would be used to store the chat data for an id